package udhaya.example.bottomnav.model

data class data_source(var text1: String) {} //val ImageResource: Int,