package udhaya.example.bottomnav.ui.view.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.navigation.fragment.findNavController
import kotlinx.android.synthetic.main.fragment_home.*
import udhaya.example.bottomnav.R
import udhaya.example.bottomnav.databinding.FragmentHomeBinding
import udhaya.example.bottomnav.ui.viewModel.Login_ViewModel


class Home : Fragment() {

    private lateinit var viewModel: Login_ViewModel
    private lateinit var binding: FragmentHomeBinding
    lateinit var button: Button
    private var views: Views? = null

    private class Views(val binding: FragmentHomeBinding)

    var counter: Int = 5
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val binding = FragmentHomeBinding.inflate(inflater, container, false)

        views = Views(binding = binding)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel = ViewModelProviders.of(this).get(Login_ViewModel::class.java)
        views?.binding?.apply {
            loginButton.setOnClickListener {
                val empty: Int = viewModel.checkBlank(
                    username = username.text.toString(),
                    password = password.text.toString()
                )
                if (empty == 1) {
                    username_text_input.error = "Username cannot be empty"
                }
                if (empty == 2) {
                    password_text_input.error = "Password cannot be empty"
                }
                viewModel.performLogin(
                    username = username.text.toString(),
                    password = password.text.toString()
                )
                val amountTv: EditText = view!!.findViewById(R.id.username_text_input)
                val amount = amountTv.text.toString().toInt()
                val action = Home.confirmationAction(amount)
                v.findNavController().navigate(action)


                viewModel.loginresult.observe(viewLifecycleOwner, Observer {
                    if (empty == 0) {
                        findNavController().navigate(R.id.action_home2_fragment_to_bnv_fragment)
                    }
                })


            }
        }
//        binding= DataBindingUtil.setContentView(activity as Activity,R.layout.fragment_home)
//        viewModel = ViewModelProviders.of(this).get(Login_ViewModel::class.java)
//        button = view.findViewById(R.id.button_login)
//        binding.apply {
//            lifecycleOwner = this@Home
//            viewmodel = this@Home.viewModel
//        }
//        initListeners()
//        initObservers()
    }
//    fun initListeners() {
//        Toast.makeText(context,"inside",Toast.LENGTH_SHORT).show()
//
//        button.setOnClickListener {
//            Toast.makeText(context,"calling",Toast.LENGTH_SHORT).show()
//            viewModel.performLogin(
//                username = login_edit_text.text.toString(),
//                password = passord_edit_text.text.toString()
//            )
//        }
//    }

//    private fun initObservers() {
//        viewModel.loginresult.observe(this, Observer { result ->
//            result?.let {
//                if (it)
//                 findNavController().navigate(R.id.action_home2_fragment_to_bnv_fragment)
//                else
//                    Toast.makeText(context, "Invalid Login", Toast.LENGTH_LONG)
//                        .show()
//            }
//        })
//    }

}
