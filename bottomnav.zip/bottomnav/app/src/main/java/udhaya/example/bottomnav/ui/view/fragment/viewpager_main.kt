package udhaya.example.bottomnav.ui.view.fragment

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import kotlinx.android.synthetic.main.fragment_viewpager_main.*
import udhaya.example.bottomnav.R

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [viewpager_main.newInstance] factory method to
 * create an instance of this fragment.
 */
class viewpager_main : Fragment() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
//        val adapter = MyViewPagerAdapter(supportFragmentManager)
//        adapter.addFragment(fragmentOne(),"One")
//        adapter.addFragment(fragmentTwo(),"Two")
//        adapter.addFragment(fragmentThree(),"Three")
//        viewPager.adapter = adapter
//        tabs.setupWithViewPager(viewPager)
        return inflater.inflate(R.layout.fragment_viewpager_main, container, false)
    }

    class MyViewPagerAdapter(manager:FragmentManager):FragmentPagerAdapter(manager){
        private val fragmentList : MutableList<Fragment> = ArrayList()
        private val titleList : MutableList<String> = ArrayList()

        override fun getItem(position: Int): Fragment {
            return fragmentList[position]
        }

        override fun getCount(): Int {
            return fragmentList.size
        }

        fun addFragment(fragment: Fragment, title: String){
            fragmentList.add(fragment)
            titleList.add(title)
        }

        override fun getPageTitle(position: Int): CharSequence? {
            return titleList[position]
        }

    }
}
