package udhaya.example.bottomnav.ui.viewModel

import android.view.View
import android.widget.Toast
import androidx.databinding.ObservableField
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import udhaya.example.bottomnav.model.data_source
import udhaya.example.bottomnav.ui.view.LoginListener
import udhaya.example.bottomnav.ui.view.fragment.weatherdata

class Login_ViewModel: ViewModel() {


    val loginresult =MutableLiveData<Boolean>()
    var username = ObservableField("")
    var password = ObservableField("")
    fun performLogin(username: String, password: String) {
        loginresult.postValue(checkCredentials(username, password))
    }
    fun checkCredentials(username: String, password: String): Boolean  {
        return username == "Udhaya" && password == "1234"
    }
    fun checkBlank(username: String, password: String): Int {
        var returnval: Int = 0
        if (username.isEmpty() || password.isEmpty()){ returnval = 1}
        if (password.isEmpty()){returnval = 2}

        return returnval
    }
    fun generateList(size : Int): ArrayList<data_source> {
        weatherdata = ArrayList()
        weatherdata.add(data_source("Canada"))
        weatherdata.add(data_source( "Australia" ))
        weatherdata.add(data_source( "India"))
        weatherdata.add(data_source( "France"))
        weatherdata.add(data_source( "Japan"))
        weatherdata.add(data_source( "Malaysia"))
        return weatherdata

    }
}

