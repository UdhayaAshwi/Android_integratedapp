package udhaya.example.bottomnav.ui.view.fragment

import android.app.Activity
import android.content.DialogInterface
import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.navigation.NavController
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

import udhaya.example.bottomnav.R

import udhaya.example.bottomnav.model.data_source
import udhaya.example.bottomnav.ui.adapter.Adapter
import udhaya.example.bottomnav.ui.viewModel.Login_ViewModel
import udhaya.example.bottomnav.ui.viewModel.MyApp

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [bnv.newInstance] factory method to
 * create an instance of this fragment.
 */
var weatherdata = ArrayList<data_source>()
var listobject: Login_ViewModel = Login_ViewModel()
private lateinit var navigationController:NavController
class bnv : Fragment(), Adapter.OnCustomClickListener {
    // TODO: Rename and change types of parameters
    private var param1: String? = null
    private var param2: String? = null
    private var pos: Int = 0
    lateinit var mAdapter: Adapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setHasOptionsMenu(true)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }
    }
    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        super.onCreateOptionsMenu(menu, inflater)
        inflater.inflate(R.menu.options_menu,menu)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val v:View = inflater.inflate(R.layout.fragment_bnv, container, false)
        val recyclerView: RecyclerView =v.findViewById(R.id.movielistview)
        val mLayoutManager: RecyclerView.LayoutManager = LinearLayoutManager(context)
        recyclerView.layoutManager = mLayoutManager
        weatherdata = listobject.generateList(10)
        mAdapter =  Adapter(weatherdata, this)
        recyclerView.adapter = mAdapter
        return v
//
 }
//    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
//        super.onViewCreated(view, savedInstanceState)
//        var button: Button = view.findViewById(R.id.item1)
//
//        button.setOnClickListener() {
//            navcontroller.navigate(R.id.action_bnv_to_settings)
//        }
//    }
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
    navigationController = findNavController()
    when(item.itemId){

        R.id.item1 -> navigationController.navigate(R.id.action_bnv_fragment_to_settings)
        R.id.item2 -> navigationController.navigate(R.id.action_bnv_fragment_to_home2_fragment)
    }
       return super.onOptionsItemSelected(item)
    }
//    fun generateList(size : Int): List<data_source> {
//        moviedata = ArrayList<data_source>()
//        moviedata.add(data_source("Avengers: End Game"))
//        moviedata.add(data_source( "Frozen" ))
//        moviedata.add(data_source( "The Incredibles"))
//        moviedata.add(data_source( "Mona"))
//        moviedata.add(data_source( "Ice Age"))
//        moviedata.add(data_source( "Inside out"))
//        return moviedata
//
//    }

    override fun onPress(dataSource: data_source) {
        Toast.makeText(
            view?.context,
            "OnPress",
            Toast.LENGTH_SHORT
        ).show()
        navigationController = findNavController()
        navigationController.navigate(R.id.action_bnv_fragment_to_fragmentActivity)
    }

    override fun onLongPress(dataSource: data_source) {
        pos = weatherdata.indexOf(dataSource)
            val builder: AlertDialog.Builder = AlertDialog.Builder(activity as Activity)
            builder.setTitle("Change Title")
            val customLayout: View = layoutInflater.inflate(R.layout.edit_layout,null)
        builder.setMessage("Change ${dataSource.text1} to : - ")
            builder.setView(customLayout)
            // add a button
            builder.setPositiveButton("OK",
                DialogInterface.OnClickListener { dialog, which ->
                    // send data from the AlertDialog to the Activity

                    val editText: EditText = customLayout.findViewById(R.id.editText)
                    if(editText.text.toString() != ""){
                    weatherdata[pos].text1 = editText.text.toString()
                    mAdapter.notifyDataSetChanged()
                    Toast.makeText(
                        view?.context,
                        "Changed to ${dataSource.text1}",
                        Toast.LENGTH_SHORT
                    ).show()}
                })
        builder.setNegativeButton("Cancel", { dialog, which ->
            dialog.dismiss()
        })
            // create and show the alert dialog
            val dialog: AlertDialog = builder.create()
            dialog.show()
        }

        // do something with the data coming from the AlertDialog
        private fun sendDialogDataToActivity(data: String) {
            Toast.makeText(view?.context, data, Toast.LENGTH_SHORT).show()
        }

    }



