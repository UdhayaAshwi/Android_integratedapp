package udhaya.example.bottomnav.ui.view

interface LoginListener {
    fun OnStarted()
    fun OnSuccess(greeting:String)
    fun OnFailure(message:String)
}