package udhaya.example.bottomnav.ui.view.activity

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import kotlinx.android.synthetic.main.activity_fragment.*
import udhaya.example.bottomnav.R
import udhaya.example.bottomnav.ui.view.fragment.fragmentOne
import udhaya.example.bottomnav.ui.view.fragment.fragmentThree
import udhaya.example.bottomnav.ui.view.fragment.fragmentTwo

class FragmentActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_fragment)

        val adapter = MyViewPagerAdapter(supportFragmentManager)
        adapter.addFragment(fragmentOne(),"Weather")
        adapter.addFragment(fragmentTwo(),"Two")
        adapter.addFragment(fragmentThree(),"Three")
        viewPager.adapter = adapter
        tabs.setupWithViewPager(viewPager)

    }
    class MyViewPagerAdapter(manager: FragmentManager) : FragmentPagerAdapter(manager) {

        private val fragmentList : MutableList<Fragment> = ArrayList()
        private val titleList : MutableList<String> = ArrayList()

        override fun getItem(position: Int): Fragment {
            return fragmentList[position]
        }

        override fun getCount(): Int {
            return fragmentList.size
        }

        fun addFragment(fragment: Fragment, title: String){
            fragmentList.add(fragment)
            titleList.add(title)
        }

        override fun getPageTitle(position: Int): CharSequence? {
            return titleList[position]
        }
    }
}